//
//  Cancelable.swift
//  NewsExercise
//
//  Created by Menahem  Vardi on 01/09/2022.
//

import Foundation

public protocol Cancellable {
    func cancel()
}
